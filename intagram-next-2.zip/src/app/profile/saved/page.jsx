import SavedPage from '@/components/pages/profile/profile/Saves/page'
import React from 'react'

const page = () => {
	return (
		<div><SavedPage /></div>
	)
}

export default page