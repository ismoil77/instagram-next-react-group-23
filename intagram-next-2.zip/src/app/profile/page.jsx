import Profiles from "@/components/pages/profile/profile/page";

export default function Profile() {
	return (
		<>
			<div>
				<Profiles/>
			</div>
		</>
	)
}
