"use client"
import React from 'react'
import PostsPage from '@/components/pages/profile/profile/Posts/posts'
const posts = () => {
	return (<><div><PostsPage /></div></>)
}

export default posts