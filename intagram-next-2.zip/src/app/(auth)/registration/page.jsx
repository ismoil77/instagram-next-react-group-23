import RegisttrationComp from '@/components/pages/auth/registration/registration'

export default function Registration() {
	return (
		<>
			<RegisttrationComp />
		</>
	)
}
