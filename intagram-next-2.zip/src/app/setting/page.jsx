import React from "react";
export default function SettingsLayout({ children }) {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Настройки</h1>
      <p>Выберите пункт меню слева, чтобы изменить настройки.</p>
    </div>
  );
}
