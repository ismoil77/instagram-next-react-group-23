import React from 'react'
import LanguageIcon from '@mui/icons-material/Language';
import { Menu, MenuItem, Divider } from '@mui/material'

const Language = () => {
    return (
        <div>
            <MenuItem><LanguageIcon /> Изменить язык</MenuItem>
        </div>

    )
}

export default Language