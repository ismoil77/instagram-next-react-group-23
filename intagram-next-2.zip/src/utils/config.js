export const API = process.env.NEXT_PUBLIC_API 
export const API_IMAGE = API + '/images'